# Superheros

## Local Setup

    rake db:create
    rake db:migrate
    rake db:seed
    rails s