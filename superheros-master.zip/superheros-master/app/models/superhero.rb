class Superhero < ActiveRecord::Base
end