require 'test_helper'

class CorgisHelperTest < ActionView::TestCase
end
