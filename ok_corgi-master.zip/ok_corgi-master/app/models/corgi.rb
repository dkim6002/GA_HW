class Corgi < ActiveRecord::Base
end
