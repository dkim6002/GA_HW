module CorgisHelper
end
